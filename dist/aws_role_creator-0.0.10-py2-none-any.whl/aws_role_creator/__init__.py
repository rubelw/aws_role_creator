from __future__ import absolute_import, division, print_function
import pkg_resources
from aws_role_creator.RoleCreator import RoleCreator #noqa

__version__ = pkg_resources.get_distribution('aws_role_creator').version

__all__ = [
]
__title__ = 'aws_role_creator'
__version__ = '0.0.10'
__author__ = 'Will Rubel'
__author_email__ = 'willrubel@gmail.com'

